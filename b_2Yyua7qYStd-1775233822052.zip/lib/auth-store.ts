// Authentication store for graphical password system
export interface ClickPoint {
  imageId: string
  x: number
  y: number
}

export interface UserCredentials {
  username: string
  mobileNumber: string
  pattern: ClickPoint[]
}

// In-memory store (for demo purposes)
let storedCredentials: UserCredentials | null = null

export function saveCredentials(credentials: UserCredentials): void {
  storedCredentials = credentials
}

export function getCredentials(): UserCredentials | null {
  return storedCredentials
}

export function validatePattern(
  inputPattern: ClickPoint[],
  tolerance: number = 20
): boolean {
  if (!storedCredentials) return false
  if (inputPattern.length !== storedCredentials.pattern.length) return false

  return inputPattern.every((inputPoint, index) => {
    const storedPoint = storedCredentials!.pattern[index]
    const xDiff = Math.abs(inputPoint.x - storedPoint.x)
    const yDiff = Math.abs(inputPoint.y - storedPoint.y)
    return (
      inputPoint.imageId === storedPoint.imageId &&
      xDiff <= tolerance &&
      yDiff <= tolerance
    )
  })
}

export function generateOTP(): string {
  return Math.floor(1000 + Math.random() * 9000).toString()
}

export function hasStoredCredentials(): boolean {
  return storedCredentials !== null
}

export function getMobileNumber(): string | null {
  return storedCredentials?.mobileNumber ?? null
}

export function clearCredentials(): void {
  storedCredentials = null
}
