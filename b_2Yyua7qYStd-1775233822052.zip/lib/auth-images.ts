// Authentication images configuration
export interface AuthImage {
  id: string
  name: string
  src: string
  alt: string
}

export const AUTH_IMAGES: AuthImage[] = [
  {
    id: 'cat',
    name: 'Cat',
    src: 'https://images.unsplash.com/photo-1514888286974-6c03e2ca1dba?w=400&h=400&fit=crop&auto=format',
    alt: 'Orange tabby cat looking up',
  },
  {
    id: 'dog',
    name: 'Dog',
    src: 'https://images.unsplash.com/photo-1587300003388-59208cc962cb?w=400&h=400&fit=crop&auto=format',
    alt: 'Golden retriever dog',
  },
  {
    id: 'lion',
    name: 'Lion',
    src: 'https://images.unsplash.com/photo-1546182990-dffeafbe841d?w=400&h=400&fit=crop&auto=format',
    alt: 'Majestic lion portrait',
  },
  {
    id: 'elephant',
    name: 'Elephant',
    src: 'https://images.unsplash.com/photo-1557050543-4d5f4e07ef46?w=400&h=400&fit=crop&auto=format',
    alt: 'African elephant',
  },
  {
    id: 'owl',
    name: 'Owl',
    src: 'https://images.unsplash.com/photo-1543549790-8b5f4a028cfb?w=400&h=400&fit=crop&auto=format',
    alt: 'Brown owl with big eyes',
  },
  {
    id: 'fox',
    name: 'Fox',
    src: 'https://images.unsplash.com/photo-1474511320723-9a56873571b7?w=400&h=400&fit=crop&auto=format',
    alt: 'Red fox in nature',
  },
]

// Shuffle array using Fisher-Yates algorithm
export function shuffleImages(images: AuthImage[]): AuthImage[] {
  const shuffled = [...images]
  for (let i = shuffled.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1))
    ;[shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]]
  }
  return shuffled
}
