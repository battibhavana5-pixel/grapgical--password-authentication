'use client'

import { useState, useEffect } from 'react'
import { motion } from 'framer-motion'
import { Shield, Clock, RefreshCw } from 'lucide-react'
import {
  InputOTP,
  InputOTPGroup,
  InputOTPSlot,
} from '@/components/ui/input-otp'
import { generateOTP, getMobileNumber } from '@/lib/auth-store'

interface OTPVerificationProps {
  onVerify: (success: boolean) => void
  onBack: () => void
}

function maskMobileNumber(number: string): string {
  if (number.length <= 4) return number
  const lastFour = number.slice(-4)
  const maskedPart = '*'.repeat(number.length - 4)
  return maskedPart + lastFour
}

export function OTPVerification({ onVerify, onBack }: OTPVerificationProps) {
  const [otp, setOtp] = useState('')
  const [generatedOTP, setGeneratedOTP] = useState('')
  const [timeLeft, setTimeLeft] = useState(60)
  const [error, setError] = useState('')
  const [mobileNumber, setMobileNumber] = useState<string | null>(null)

  useEffect(() => {
    setGeneratedOTP(generateOTP())
    setMobileNumber(getMobileNumber())
  }, [])

  useEffect(() => {
    if (timeLeft <= 0) return

    const timer = setInterval(() => {
      setTimeLeft((prev) => prev - 1)
    }, 1000)

    return () => clearInterval(timer)
  }, [timeLeft])

  const handleResendOTP = () => {
    setGeneratedOTP(generateOTP())
    setTimeLeft(60)
    setOtp('')
    setError('')
  }

  const handleVerify = () => {
    if (otp === generatedOTP) {
      onVerify(true)
    } else {
      setError('Invalid OTP. Please try again.')
      onVerify(false)
    }
  }

  const handleOTPChange = (value: string) => {
    setOtp(value)
    setError('')
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -20 }}
      className="flex flex-col items-center gap-8"
    >
      {/* OTP Display (Demo) */}
      <div className="w-full rounded-xl border border-primary/30 bg-primary/5 p-6">
        <div className="mb-3 flex items-center justify-center gap-2">
          <Shield className="h-5 w-5 text-primary" />
          <span className="text-sm font-medium text-muted-foreground">
            Your OTP (Demo Display)
          </span>
        </div>
        <div className="flex items-center justify-center gap-2">
          {generatedOTP.split('').map((digit, index) => (
            <motion.span
              key={index}
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              transition={{ delay: index * 0.1 }}
              className="flex h-14 w-14 items-center justify-center rounded-lg border border-primary bg-primary/10 text-2xl font-mono font-bold text-primary"
            >
              {digit}
            </motion.span>
          ))}
        </div>
        <p className="mt-3 text-center text-xs text-muted-foreground">
          {mobileNumber ? (
            <>
              OTP sent to{' '}
              <span className="font-mono font-semibold text-primary">
                {maskMobileNumber(mobileNumber)}
              </span>{' '}
              (Demo - displayed here)
            </>
          ) : (
            'In a real app, this would be sent via SMS/Email'
          )}
        </p>
      </div>

      {/* Timer */}
      <div className="flex items-center gap-2 text-sm">
        <Clock className="h-4 w-4 text-muted-foreground" />
        <span className="text-muted-foreground">
          {timeLeft > 0 ? (
            <>
              OTP expires in{' '}
              <span className="font-mono font-semibold text-foreground">
                {timeLeft}s
              </span>
            </>
          ) : (
            <span className="text-destructive">OTP expired</span>
          )}
        </span>
      </div>

      {/* OTP Input */}
      <div className="flex flex-col items-center gap-4">
        <label className="text-sm font-medium text-foreground">
          Enter the 4-digit OTP
        </label>
        <InputOTP
          maxLength={4}
          value={otp}
          onChange={handleOTPChange}
          disabled={timeLeft <= 0}
        >
          <InputOTPGroup>
            <InputOTPSlot index={0} className="h-14 w-14 text-xl" />
            <InputOTPSlot index={1} className="h-14 w-14 text-xl" />
            <InputOTPSlot index={2} className="h-14 w-14 text-xl" />
            <InputOTPSlot index={3} className="h-14 w-14 text-xl" />
          </InputOTPGroup>
        </InputOTP>

        {error && (
          <motion.p
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-sm text-destructive"
          >
            {error}
          </motion.p>
        )}
      </div>

      {/* Actions */}
      <div className="flex w-full flex-col gap-3 sm:flex-row sm:justify-center">
        <button
          onClick={onBack}
          className="rounded-lg border border-border bg-secondary px-6 py-3 text-sm font-medium text-foreground transition-colors hover:bg-muted"
        >
          Back
        </button>
        <button
          onClick={handleResendOTP}
          disabled={timeLeft > 0}
          className="flex items-center justify-center gap-2 rounded-lg border border-border bg-secondary px-6 py-3 text-sm font-medium text-foreground transition-colors hover:bg-muted disabled:cursor-not-allowed disabled:opacity-50"
        >
          <RefreshCw className="h-4 w-4" />
          Resend OTP
        </button>
        <button
          onClick={handleVerify}
          disabled={otp.length !== 4 || timeLeft <= 0}
          className="rounded-lg bg-primary px-6 py-3 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90 disabled:cursor-not-allowed disabled:opacity-50"
        >
          Verify OTP
        </button>
      </div>
    </motion.div>
  )
}
