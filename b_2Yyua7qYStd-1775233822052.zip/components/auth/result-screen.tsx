'use client'

import { motion } from 'framer-motion'
import { CheckCircle2, XCircle, Shield, ArrowRight } from 'lucide-react'
import { cn } from '@/lib/utils'

interface ResultScreenProps {
  success: boolean
  message: string
  onTryAgain?: () => void
  onContinue?: () => void
}

export function ResultScreen({
  success,
  message,
  onTryAgain,
  onContinue,
}: ResultScreenProps) {
  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.9 }}
      animate={{ opacity: 1, scale: 1 }}
      exit={{ opacity: 0, scale: 0.9 }}
      className="flex flex-col items-center gap-6 text-center"
    >
      {/* Icon */}
      <motion.div
        initial={{ scale: 0 }}
        animate={{ scale: 1 }}
        transition={{ delay: 0.2, type: 'spring', stiffness: 200 }}
        className={cn(
          'flex h-24 w-24 items-center justify-center rounded-full',
          success
            ? 'bg-primary/20 text-primary'
            : 'bg-destructive/20 text-destructive'
        )}
      >
        {success ? (
          <CheckCircle2 className="h-12 w-12" />
        ) : (
          <XCircle className="h-12 w-12" />
        )}
      </motion.div>

      {/* Title */}
      <motion.h2
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.3 }}
        className={cn(
          'text-2xl font-bold',
          success ? 'text-primary' : 'text-destructive'
        )}
      >
        {success ? 'Access Granted' : 'Access Denied'}
      </motion.h2>

      {/* Message */}
      <motion.p
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.4 }}
        className="max-w-md text-muted-foreground"
      >
        {message}
      </motion.p>

      {/* Status indicator */}
      {success && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
          className="flex items-center gap-2 rounded-full border border-primary/30 bg-primary/10 px-4 py-2"
        >
          <Shield className="h-4 w-4 text-primary" />
          <span className="text-sm font-medium text-primary">
            Authenticated Successfully
          </span>
        </motion.div>
      )}

      {/* Actions */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.6 }}
        className="flex flex-col gap-3 pt-4 sm:flex-row"
      >
        {onTryAgain && (
          <button
            onClick={onTryAgain}
            className="rounded-lg border border-border bg-secondary px-6 py-3 text-sm font-medium text-foreground transition-colors hover:bg-muted"
          >
            Try Again
          </button>
        )}
        {onContinue && (
          <button
            onClick={onContinue}
            className="flex items-center justify-center gap-2 rounded-lg bg-primary px-6 py-3 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90"
          >
            Continue
            <ArrowRight className="h-4 w-4" />
          </button>
        )}
      </motion.div>
    </motion.div>
  )
}
