'use client'

import { useState, useCallback } from 'react'
import Image from 'next/image'
import { motion, AnimatePresence } from 'framer-motion'
import { Check, X, MousePointer2 } from 'lucide-react'
import { cn } from '@/lib/utils'
import type { AuthImage } from '@/lib/auth-images'
import type { ClickPoint } from '@/lib/auth-store'

interface ImageGridProps {
  images: AuthImage[]
  onPatternComplete: (pattern: ClickPoint[]) => void
  mode: 'register' | 'login'
  requiredClicks?: number
}

interface ClickMarker {
  imageId: string
  x: number
  y: number
  order: number
}

export function ImageGrid({
  images,
  onPatternComplete,
  mode,
  requiredClicks = 3,
}: ImageGridProps) {
  const [clickMarkers, setClickMarkers] = useState<ClickMarker[]>([])
  const [selectedImages, setSelectedImages] = useState<Set<string>>(new Set())

  const handleImageClick = useCallback(
    (imageId: string, event: React.MouseEvent<HTMLDivElement>) => {
      const rect = event.currentTarget.getBoundingClientRect()
      const relativeX = event.clientX - rect.left
      const relativeY = event.clientY - rect.top

      const xPercent = (relativeX / rect.width) * 100
      const yPercent = (relativeY / rect.height) * 100

      const newMarker: ClickMarker = {
        imageId,
        x: xPercent,
        y: yPercent,
        order: clickMarkers.length + 1,
      }

      setClickMarkers((prev) => [...prev, newMarker])
      setSelectedImages((prev) => new Set(prev).add(imageId))
    },
    [clickMarkers.length]
  )

  const handleUndo = useCallback(() => {
    setClickMarkers((prev) => {
      const newMarkers = prev.slice(0, -1)
      const remainingImageIds = new Set(newMarkers.map((m) => m.imageId))
      setSelectedImages(remainingImageIds)
      return newMarkers
    })
  }, [])

  const handleReset = useCallback(() => {
    setClickMarkers([])
    setSelectedImages(new Set())
  }, [])

  const handleConfirm = useCallback(() => {
    const pattern: ClickPoint[] = clickMarkers.map((marker) => ({
      imageId: marker.imageId,
      x: marker.x,
      y: marker.y,
    }))
    onPatternComplete(pattern)
  }, [clickMarkers, onPatternComplete])

  const canConfirm = clickMarkers.length >= requiredClicks

  return (
    <div className="flex flex-col gap-6">
      {/* Instructions */}
      <div className="flex items-center gap-3 rounded-lg border border-border bg-secondary/50 p-4">
        <MousePointer2 className="h-5 w-5 text-primary" />
        <p className="text-sm text-muted-foreground">
          {mode === 'register'
            ? `Click on ${requiredClicks} or more spots across the images to create your secret pattern. Remember the order!`
            : 'Click the same spots in the same order as you registered.'}
        </p>
      </div>

      {/* Image Grid */}
      <div className="grid grid-cols-2 gap-4 md:grid-cols-3">
        <AnimatePresence mode="popLayout">
          {images.map((image, index) => (
            <motion.div
              key={image.id}
              layout
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.8 }}
              transition={{ duration: 0.3, delay: index * 0.05 }}
              className={cn(
                'relative aspect-square overflow-hidden rounded-xl border-2 transition-all duration-200',
                selectedImages.has(image.id)
                  ? 'border-primary shadow-lg shadow-primary/20'
                  : 'border-border hover:border-muted-foreground'
              )}
            >
              {/* Clickable overlay */}
              <div
                onClick={(e) => handleImageClick(image.id, e)}
                className="absolute inset-0 z-10 cursor-crosshair"
              />
              <Image
                src={image.src}
                alt={image.alt}
                fill
                className="object-cover"
                sizes="(max-width: 768px) 50vw, 33vw"
                crossOrigin="anonymous"
              />

              {/* Click markers on this image */}
              {clickMarkers
                .filter((marker) => marker.imageId === image.id)
                .map((marker) => (
                  <motion.div
                    key={`${marker.imageId}-${marker.order}`}
                    initial={{ scale: 0, opacity: 0 }}
                    animate={{ scale: 1, opacity: 1 }}
                    exit={{ scale: 0, opacity: 0 }}
                    className="pointer-events-none absolute z-20 flex h-8 w-8 -translate-x-1/2 -translate-y-1/2 items-center justify-center rounded-full bg-primary text-sm font-bold text-primary-foreground shadow-lg"
                    style={{
                      left: `${marker.x}%`,
                      top: `${marker.y}%`,
                    }}
                  >
                    {marker.order}
                  </motion.div>
                ))}

              {/* Image label */}
              <div className="pointer-events-none absolute bottom-0 left-0 right-0 z-20 bg-gradient-to-t from-black/80 to-transparent p-3">
                <span className="text-sm font-medium text-white">
                  {image.name}
                </span>
              </div>
            </motion.div>
          ))}
        </AnimatePresence>
      </div>

      {/* Click counter and actions */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div className="flex items-center gap-2">
          <span className="text-sm text-muted-foreground">
            Clicks recorded:
          </span>
          <span
            className={cn(
              'rounded-md px-3 py-1 font-mono text-sm font-semibold',
              canConfirm
                ? 'bg-primary/20 text-primary'
                : 'bg-secondary text-foreground'
            )}
          >
            {clickMarkers.length} / {requiredClicks}+
          </span>
        </div>

        <div className="flex gap-3">
          <button
            onClick={handleUndo}
            disabled={clickMarkers.length === 0}
            className="flex items-center gap-2 rounded-lg border border-border bg-secondary px-4 py-2 text-sm font-medium text-foreground transition-colors hover:bg-muted disabled:cursor-not-allowed disabled:opacity-50"
          >
            <X className="h-4 w-4" />
            Undo
          </button>
          <button
            onClick={handleReset}
            disabled={clickMarkers.length === 0}
            className="flex items-center gap-2 rounded-lg border border-border bg-secondary px-4 py-2 text-sm font-medium text-foreground transition-colors hover:bg-muted disabled:cursor-not-allowed disabled:opacity-50"
          >
            Reset
          </button>
          <button
            onClick={handleConfirm}
            disabled={!canConfirm}
            className="flex items-center gap-2 rounded-lg bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90 disabled:cursor-not-allowed disabled:opacity-50"
          >
            <Check className="h-4 w-4" />
            {mode === 'register' ? 'Save Pattern' : 'Verify Pattern'}
          </button>
        </div>
      </div>
    </div>
  )
}
