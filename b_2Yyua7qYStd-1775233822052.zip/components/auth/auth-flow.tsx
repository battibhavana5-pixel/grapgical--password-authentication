'use client'

import { useState, useCallback, useMemo } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import {
  Shield,
  UserPlus,
  LogIn,
  ArrowLeft,
  Lock,
  Fingerprint,
} from 'lucide-react'
import { ImageGrid } from './image-grid'
import { OTPVerification } from './otp-verification'
import { ResultScreen } from './result-screen'
import { AUTH_IMAGES, shuffleImages } from '@/lib/auth-images'
import {
  saveCredentials,
  validatePattern,
  hasStoredCredentials,
  clearCredentials,
  type ClickPoint,
} from '@/lib/auth-store'
import { Input } from '@/components/ui/input'
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card'
import { cn } from '@/lib/utils'

type AuthStep =
  | 'welcome'
  | 'register-pattern'
  | 'login-pattern'
  | 'otp'
  | 'result'
type AuthMode = 'register' | 'login'

export function AuthFlow() {
  const [step, setStep] = useState<AuthStep>('welcome')
  const [mode, setMode] = useState<AuthMode>('register')
  const [username, setUsername] = useState('')
  const [mobileNumber, setMobileNumber] = useState('')
  const [usernameError, setUsernameError] = useState('')
  const [mobileError, setMobileError] = useState('')
  const [loginPattern, setLoginPattern] = useState<ClickPoint[]>([])
  const [authSuccess, setAuthSuccess] = useState(false)
  const [resultMessage, setResultMessage] = useState('')

  // Memoize shuffled images for login (only shuffles once per login attempt)
  const shuffledImages = useMemo(() => shuffleImages(AUTH_IMAGES), [step])

  const handleStartRegister = useCallback(() => {
    let hasError = false
    if (!username.trim()) {
      setUsernameError('Please enter a username')
      hasError = true
    } else {
      setUsernameError('')
    }
    
    if (!mobileNumber.trim()) {
      setMobileError('Please enter a mobile number')
      hasError = true
    } else if (!/^\d{10}$/.test(mobileNumber.replace(/\D/g, ''))) {
      setMobileError('Please enter a valid 10-digit mobile number')
      hasError = true
    } else {
      setMobileError('')
    }
    
    if (hasError) return
    
    setMode('register')
    setStep('register-pattern')
  }, [username, mobileNumber])

  const handleStartLogin = useCallback(() => {
    if (!hasStoredCredentials()) {
      setUsernameError('No registered user found. Please register first.')
      return
    }
    if (!username.trim()) {
      setUsernameError('Please enter your username')
      return
    }
    setUsernameError('')
    setMode('login')
    setStep('login-pattern')
  }, [username])

  const handlePatternComplete = useCallback(
    (pattern: ClickPoint[]) => {
      if (mode === 'register') {
        // Save the pattern with mobile number
        saveCredentials({ username, mobileNumber, pattern })
        setAuthSuccess(true)
        setResultMessage(
          'Your graphical password has been saved successfully. You can now log in using the same pattern.'
        )
        setStep('result')
      } else {
        // Validate the pattern
        const isValid = validatePattern(pattern)
        if (isValid) {
          setLoginPattern(pattern)
          setStep('otp')
        } else {
          setAuthSuccess(false)
          setResultMessage(
            'The pattern you entered does not match. Please try again with the correct click positions.'
          )
          setStep('result')
        }
      }
    },
    [mode, username, mobileNumber]
  )

  const handleOTPVerify = useCallback((success: boolean) => {
    if (success) {
      setAuthSuccess(true)
      setResultMessage(
        'Two-factor authentication complete. You have been granted access to the secure system.'
      )
    } else {
      setAuthSuccess(false)
      setResultMessage('OTP verification failed. Please try again.')
    }
    setStep('result')
  }, [])

  const handleTryAgain = useCallback(() => {
    setStep('welcome')
    setAuthSuccess(false)
    setResultMessage('')
    setLoginPattern([])
  }, [])

  const handleContinue = useCallback(() => {
    setStep('welcome')
    setAuthSuccess(false)
    setResultMessage('')
    setLoginPattern([])
    if (mode === 'register') {
      setUsername('')
      setMobileNumber('')
    }
  }, [mode])

  const handleBack = useCallback(() => {
    if (step === 'otp') {
      setStep('login-pattern')
    } else {
      setStep('welcome')
    }
  }, [step])

  const handleClearData = useCallback(() => {
    clearCredentials()
    setStep('welcome')
    setUsername('')
    setMobileNumber('')
  }, [])

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border bg-card/50 backdrop-blur-sm">
        <div className="mx-auto flex max-w-6xl items-center justify-between px-4 py-4">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary">
              <Shield className="h-5 w-5 text-primary-foreground" />
            </div>
            <div>
              <h1 className="text-lg font-bold text-foreground">SecureAuth</h1>
              <p className="text-xs text-muted-foreground">
                Graphical Password System
              </p>
            </div>
          </div>
          {hasStoredCredentials() && step === 'welcome' && (
            <button
              onClick={handleClearData}
              className="text-sm text-muted-foreground transition-colors hover:text-foreground"
            >
              Clear saved data
            </button>
          )}
        </div>
      </header>

      {/* Main Content */}
      <main className="mx-auto max-w-4xl px-4 py-8">
        <AnimatePresence mode="wait">
          {/* Welcome Screen */}
          {step === 'welcome' && (
            <motion.div
              key="welcome"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="flex flex-col gap-8"
            >
              {/* Hero Section */}
              <div className="text-center">
                <motion.div
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  transition={{ delay: 0.2, type: 'spring' }}
                  className="mx-auto mb-6 flex h-20 w-20 items-center justify-center rounded-2xl bg-primary/10"
                >
                  <Fingerprint className="h-10 w-10 text-primary" />
                </motion.div>
                <h2 className="mb-3 text-3xl font-bold text-foreground text-balance">
                  High-Security Authentication
                </h2>
                <p className="mx-auto max-w-xl text-muted-foreground text-pretty">
                  Protect your account with our advanced 2-layer authentication
                  system. Create a unique graphical password by clicking
                  specific spots on images, then verify with OTP.
                </p>
              </div>

              {/* Features */}
              <div className="grid gap-4 sm:grid-cols-3">
                {[
                  {
                    icon: Lock,
                    title: 'Graphical Password',
                    description:
                      'Click patterns on images that only you know',
                  },
                  {
                    icon: Shield,
                    title: 'OTP Verification',
                    description: 'Second layer of security with one-time codes',
                  },
                  {
                    icon: Fingerprint,
                    title: 'Secure & Unique',
                    description: 'Nearly impossible to guess or brute-force',
                  },
                ].map((feature, index) => (
                  <motion.div
                    key={feature.title}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.3 + index * 0.1 }}
                    className="rounded-xl border border-border bg-card/50 p-4 text-center"
                  >
                    <feature.icon className="mx-auto mb-2 h-6 w-6 text-primary" />
                    <h3 className="mb-1 font-semibold text-foreground">
                      {feature.title}
                    </h3>
                    <p className="text-sm text-muted-foreground">
                      {feature.description}
                    </p>
                  </motion.div>
                ))}
              </div>

              {/* Username Input */}
              <Card className="border-border bg-card/50">
                <CardHeader className="pb-4">
                  <CardTitle className="text-lg">Get Started</CardTitle>
                  <CardDescription>
                    Enter your username to register or login
                  </CardDescription>
                </CardHeader>
                <CardContent className="flex flex-col gap-4">
                  <div>
                    <Input
                      type="text"
                      placeholder="Enter username"
                      value={username}
                      onChange={(e) => {
                        setUsername(e.target.value)
                        setUsernameError('')
                      }}
                      className="h-12 bg-secondary/50"
                    />
                    {usernameError && (
                      <p className="mt-2 text-sm text-destructive">
                        {usernameError}
                      </p>
                    )}
                  </div>
                  <div>
                    <Input
                      type="tel"
                      placeholder="Enter mobile number (for OTP)"
                      value={mobileNumber}
                      onChange={(e) => {
                        setMobileNumber(e.target.value)
                        setMobileError('')
                      }}
                      className="h-12 bg-secondary/50"
                    />
                    {mobileError && (
                      <p className="mt-2 text-sm text-destructive">
                        {mobileError}
                      </p>
                    )}
                    <p className="mt-1 text-xs text-muted-foreground">
                      For demo: OTP will be displayed on screen
                    </p>
                  </div>

                  <div className="grid gap-3 sm:grid-cols-2">
                    <button
                      onClick={handleStartRegister}
                      className="flex h-12 items-center justify-center gap-2 rounded-lg border border-primary bg-primary/10 text-sm font-medium text-primary transition-colors hover:bg-primary/20"
                    >
                      <UserPlus className="h-4 w-4" />
                      Register New Account
                    </button>
                    <button
                      onClick={handleStartLogin}
                      className="flex h-12 items-center justify-center gap-2 rounded-lg bg-primary text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90"
                    >
                      <LogIn className="h-4 w-4" />
                      Login
                    </button>
                  </div>

                  {hasStoredCredentials() && (
                    <p className="text-center text-sm text-primary">
                      A user is already registered. You can login or register a
                      new pattern.
                    </p>
                  )}
                </CardContent>
              </Card>
            </motion.div>
          )}

          {/* Register Pattern Screen */}
          {step === 'register-pattern' && (
            <motion.div
              key="register-pattern"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="flex flex-col gap-6"
            >
              <div className="flex items-center gap-4">
                <button
                  onClick={handleBack}
                  className="flex h-10 w-10 items-center justify-center rounded-lg border border-border bg-secondary transition-colors hover:bg-muted"
                >
                  <ArrowLeft className="h-5 w-5" />
                </button>
                <div>
                  <h2 className="text-2xl font-bold text-foreground">
                    Create Your Pattern
                  </h2>
                  <p className="text-muted-foreground">
                    Welcome, <span className="text-primary">{username}</span>!
                    Create your graphical password.
                  </p>
                </div>
              </div>

              <ImageGrid
                images={AUTH_IMAGES}
                onPatternComplete={handlePatternComplete}
                mode="register"
                requiredClicks={3}
              />
            </motion.div>
          )}

          {/* Login Pattern Screen */}
          {step === 'login-pattern' && (
            <motion.div
              key="login-pattern"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="flex flex-col gap-6"
            >
              <div className="flex items-center gap-4">
                <button
                  onClick={handleBack}
                  className="flex h-10 w-10 items-center justify-center rounded-lg border border-border bg-secondary transition-colors hover:bg-muted"
                >
                  <ArrowLeft className="h-5 w-5" />
                </button>
                <div>
                  <h2 className="text-2xl font-bold text-foreground">
                    Verify Your Pattern
                  </h2>
                  <p className="text-muted-foreground">
                    Welcome back, <span className="text-primary">{username}</span>!
                    Enter your pattern to continue.
                  </p>
                </div>
              </div>

              {/* Notice about shuffled images */}
              <div className="rounded-lg border border-primary/30 bg-primary/5 p-4">
                <p className="text-sm text-primary">
                  <strong>Note:</strong> Images are shuffled for security. Find
                  and click the same spots you registered.
                </p>
              </div>

              <ImageGrid
                images={shuffledImages}
                onPatternComplete={handlePatternComplete}
                mode="login"
                requiredClicks={3}
              />
            </motion.div>
          )}

          {/* OTP Screen */}
          {step === 'otp' && (
            <motion.div
              key="otp"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="flex flex-col gap-6"
            >
              <div className="text-center">
                <h2 className="mb-2 text-2xl font-bold text-foreground">
                  OTP Verification
                </h2>
                <p className="text-muted-foreground">
                  Pattern verified! Please enter the OTP to complete
                  authentication.
                </p>
              </div>

              <Card className="mx-auto w-full max-w-md border-border bg-card/50">
                <CardContent className="pt-6">
                  <OTPVerification onVerify={handleOTPVerify} onBack={handleBack} />
                </CardContent>
              </Card>
            </motion.div>
          )}

          {/* Result Screen */}
          {step === 'result' && (
            <motion.div
              key="result"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
            >
              <Card className="mx-auto w-full max-w-md border-border bg-card/50">
                <CardContent className="pt-8 pb-8">
                  <ResultScreen
                    success={authSuccess}
                    message={resultMessage}
                    onTryAgain={!authSuccess ? handleTryAgain : undefined}
                    onContinue={handleContinue}
                  />
                </CardContent>
              </Card>
            </motion.div>
          )}
        </AnimatePresence>
      </main>

      {/* Footer */}
      <footer className="border-t border-border bg-card/30">
        <div className="mx-auto max-w-6xl px-4 py-4 text-center">
          <p className="text-sm text-muted-foreground">
            SecureAuth Demo &mdash; Graphical Password + OTP Authentication
            System
          </p>
        </div>
      </footer>
    </div>
  )
}
